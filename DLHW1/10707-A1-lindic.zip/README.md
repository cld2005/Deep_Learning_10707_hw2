# Deep_Learning_10707


## homework1


In this assignment, the softwares are developed for question 6 a to i.
Each sub-question have at least one main script to run, except question 6 a,b, and c which share one main script.

The the question numbers are added to the suffix if the main script.
For example to run question 6 a,c and c just execute main_6_abc.m in MatLab.

The main script contains the setting for number of rounds, number of hidden layers, hidden layer size, learning rate, batch size,
 number of epochs, momentum, regularization, and setting for batch normalization. If you want to create your own main script, please change accordingly.
  
  