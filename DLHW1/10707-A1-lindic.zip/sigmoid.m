function y = sigmoid(x)

y=1.0/(1.0+exp(-x));

end
