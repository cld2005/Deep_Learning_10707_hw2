% batch_size=10;
% for batch = 0:3000/batch_size-1
%     for sub_index = 1:batch_size
%         sample_index = batch*batch_size+sub_index;
%         fprintf('%d\n',sample_index);
%     end 
%     fprintf('new batch\n');
% end


